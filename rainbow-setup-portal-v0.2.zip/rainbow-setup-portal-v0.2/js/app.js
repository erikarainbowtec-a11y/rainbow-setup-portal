const STORAGE_KEY = 'rainbowSetupPortalV02';
const SESSION_KEY = 'rainbowSetupSession';

const initialProjects = [
  { id: crypto.randomUUID(), client: 'ODATA', name: 'Implantação México', country: 'México', language: 'Español', consultant: 'Erika Chaves', deadline: '2026-09-04', progress: 64, status: 'Em andamento' },
  { id: crypto.randomUUID(), client: 'CMPC', name: 'POC Chile', country: 'Chile', language: 'Español', consultant: 'Erika Chaves', deadline: '2026-08-15', progress: 100, status: 'Concluído' },
  { id: crypto.randomUUID(), client: 'NEXA', name: 'Gestão de Terceiros Peru', country: 'Peru', language: 'Español', consultant: 'Erika Chaves', deadline: '2026-10-10', progress: 25, status: 'Em andamento' }
];

let state = loadState();
let currentWizardStep = 0;
let activeProjectId = state.activeProjectId || state.projects[0]?.id;

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return saved && Array.isArray(saved.projects) ? saved : { projects: initialProjects, forms: {}, activeProjectId: initialProjects[0].id };
  } catch {
    return { projects: initialProjects, forms: {}, activeProjectId: initialProjects[0].id };
  }
}

function persist() {
  state.activeProjectId = activeProjectId;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('show'), 2600);
}

function statusClass(status) {
  if (status === 'Concluído') return 'done';
  if (status === 'Não iniciado') return 'new';
  return 'progressing';
}

function projectCard(project) {
  return `<article class="project-card">
    <div class="project-top"><div><span class="country-tag">${project.country}</span><h4>${project.client} — ${project.name}</h4></div><span class="status-tag ${statusClass(project.status)}">${project.status}</span></div>
    <div><div class="progress-label"><span>Progresso</span><strong>${project.progress}%</strong></div><div class="progress"><span style="width:${project.progress}%"></span></div></div>
    <div class="project-meta"><span>Consultor: ${project.consultant}</span><span>${project.deadline || 'Sem data'}</span></div>
    <button class="btn secondary open-project" data-id="${project.id}">Abrir projeto</button>
  </article>`;
}

function renderDashboard() {
  $('#dashboardProjects').innerHTML = state.projects.slice(0, 6).map(projectCard).join('');
  $('#metricProjects').textContent = state.projects.length;
  $('#metricProgress').textContent = state.projects.filter(p => p.status === 'Em andamento').length;
  $('#metricDone').textContent = state.projects.filter(p => p.status === 'Concluído').length;
  const avg = state.projects.length ? Math.round(state.projects.reduce((a, p) => a + p.progress, 0) / state.projects.length) : 0;
  $('#metricAverage').textContent = `${avg}%`;
  bindOpenProjectButtons();
}

function renderProjects() {
  const query = $('#projectSearch')?.value.toLowerCase() || '';
  const filter = $('#projectStatusFilter')?.value || 'all';
  const projects = state.projects.filter(p => `${p.client} ${p.name} ${p.country}`.toLowerCase().includes(query) && (filter === 'all' || p.status === filter));
  $('#projectsTable').innerHTML = `<table class="projects-table"><thead><tr><th>Cliente / Projeto</th><th>País</th><th>Status</th><th>Progresso</th><th>Consultor</th><th></th></tr></thead><tbody>${projects.map(p => `<tr>
    <td data-label="Projeto"><strong>${p.client}</strong><br><span class="muted">${p.name}</span></td>
    <td data-label="País">${p.country}</td><td data-label="Status"><span class="status-tag ${statusClass(p.status)}">${p.status}</span></td>
    <td data-label="Progresso"><strong>${p.progress}%</strong></td><td data-label="Consultor">${p.consultant}</td>
    <td data-label="Ação"><button class="btn secondary open-project" data-id="${p.id}">Abrir</button></td></tr>`).join('')}</tbody></table>`;
  bindOpenProjectButtons();
}

function bindOpenProjectButtons() {
  $$('.open-project').forEach(btn => btn.onclick = () => openProject(btn.dataset.id));
}

function openProject(id) {
  activeProjectId = id;
  persist();
  currentWizardStep = 0;
  loadWizardData();
  switchView('wizard');
}

function switchView(viewId) {
  $$('.view').forEach(v => v.classList.toggle('active', v.id === viewId));
  $$('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.view === viewId));
  const labels = { dashboard: ['Dashboard', 'Visão geral'], projects: ['Projetos', 'Gestão de implantações'], wizard: ['Parametrização', 'Assistente de configuração'], reports: ['Relatórios', 'Indicadores'], settings: ['Configurações', 'Preferências'] };
  $('#breadcrumb').textContent = labels[viewId][0];
  $('#pageTitle').textContent = labels[viewId][1];
  $('#sidebar').classList.remove('open');
  if (viewId === 'projects') renderProjects();
  if (viewId === 'wizard') loadWizardData();
}

function setupNavigation() {
  $$('.nav-item').forEach(item => item.onclick = () => switchView(item.dataset.view));
  $$('[data-view-link]').forEach(item => item.onclick = () => switchView(item.dataset.viewLink));
  $$('[data-action="new-project"]').forEach(item => item.onclick = () => $('#projectDialog').showModal());
  $('#menuButton').onclick = () => $('#sidebar').classList.toggle('open');
  $('#logoutButton').onclick = () => { sessionStorage.removeItem(SESSION_KEY); $('#appView').classList.add('hidden'); $('#loginView').classList.remove('hidden'); };
}

function setupLogin() {
  $('#loginForm').addEventListener('submit', event => {
    event.preventDefault();
    sessionStorage.setItem(SESSION_KEY, 'active');
    $('#loginView').classList.add('hidden');
    $('#appView').classList.remove('hidden');
    renderDashboard(); renderProjects(); loadWizardData();
  });
  if (sessionStorage.getItem(SESSION_KEY)) {
    $('#loginView').classList.add('hidden');
    $('#appView').classList.remove('hidden');
  }
}

function setupProjectDialog() {
  $('#projectForm').addEventListener('submit', event => {
    event.preventDefault();
    const submitter = event.submitter;
    if (!submitter || submitter.value !== 'default') return;
    const formData = new FormData(event.currentTarget);
    const project = {
      id: crypto.randomUUID(), client: formData.get('client'), name: formData.get('name'), country: formData.get('country'), language: formData.get('language'), consultant: formData.get('consultant') || 'Erika Chaves', deadline: formData.get('deadline'), progress: 0, status: 'Não iniciado'
    };
    state.projects.unshift(project); activeProjectId = project.id; persist();
    event.currentTarget.reset(); $('#projectDialog').close(); renderDashboard(); renderProjects(); showToast('Projeto criado com sucesso.'); openProject(project.id);
  });
}

const wizardSections = $$('.wizard-section');

function renderWizardSteps() {
  $('#wizardSteps').innerHTML = wizardSections.map((section, index) => `<button class="wizard-step ${index === currentWizardStep ? 'active' : ''} ${index < currentWizardStep ? 'done' : ''}" data-step="${index}"><span class="step-number">${index < currentWizardStep ? '✓' : index + 1}</span><span>${section.dataset.title}</span></button>`).join('');
  $$('.wizard-step').forEach(button => button.onclick = () => { saveWizardData(false); currentWizardStep = Number(button.dataset.step); updateWizard(); });
}

function updateWizard() {
  wizardSections.forEach((section, index) => section.classList.toggle('active', index === currentWizardStep));
  renderWizardSteps();
  const percent = Math.round(((currentWizardStep + 1) / wizardSections.length) * 100);
  $('#wizardPercent').textContent = `${percent}%`;
  $('#wizardProgressBar').style.width = `${percent}%`;
  $('#previousButton').disabled = currentWizardStep === 0;
  $('#nextButton').textContent = currentWizardStep === wizardSections.length - 1 ? 'Finalizar' : 'Próximo →';
  if (currentWizardStep === wizardSections.length - 1) renderReview();
}

function getActiveProject() { return state.projects.find(p => p.id === activeProjectId) || state.projects[0]; }

function collectWizardData() {
  const data = {};
  $$('#wizard input, #wizard select, #wizard textarea').forEach(el => {
    if (!el.name) return;
    data[el.name] = el.type === 'checkbox' ? el.checked : el.value;
  });
  data.documents = $$('#documentsBody tr').map(row => ({ type: $('[data-field="type"]', row).value, name: $('[data-field="name"]', row).value, required: $('[data-field="required"]', row).value, periodicity: $('[data-field="periodicity"]', row).value, validation: $('[data-field="validation"]', row).value }));
  data.savedAt = new Date().toISOString();
  return data;
}

function saveWizardData(notify = true) {
  if (!activeProjectId) return;
  state.forms[activeProjectId] = collectWizardData();
  const project = getActiveProject();
  const filled = $$('#wizard input, #wizard select, #wizard textarea').filter(el => el.name && (el.type === 'checkbox' ? el.checked : String(el.value).trim())).length;
  const total = $$('#wizard input, #wizard select, #wizard textarea').filter(el => el.name).length || 1;
  project.progress = Math.min(99, Math.max(project.progress, Math.round((filled / total) * 100)));
  if (project.progress > 0 && project.status === 'Não iniciado') project.status = 'Em andamento';
  persist(); renderDashboard(); renderProjects();
  if (notify) showToast('Avanço salvo neste navegador.');
}

function loadWizardData() {
  const project = getActiveProject();
  if (!project) return;
  $('#wizardProjectTitle').textContent = `${project.client} — ${project.name}`;
  const data = state.forms[project.id] || { cliente: project.client, pais: project.country, projeto: project.name, consultor: project.consultant, golive: project.deadline };
  $$('#wizard input, #wizard select, #wizard textarea').forEach(el => {
    if (!el.name || data[el.name] === undefined) return;
    if (el.type === 'checkbox') el.checked = Boolean(data[el.name]); else el.value = data[el.name];
  });
  $('#documentsBody').innerHTML = '';
  const docs = data.documents?.length ? data.documents : [{ type: 'Trabalhador', name: 'Documento de identidade', required: 'Sim', periodicity: 'Conforme vencimento', validation: 'Manual' }];
  docs.forEach(addDocumentRow);
  updateWizard();
}

function addDocumentRow(doc = {}) {
  const row = document.createElement('tr');
  row.innerHTML = `<td><select data-field="type"><option ${doc.type === 'Empresa' ? 'selected' : ''}>Empresa</option><option ${doc.type === 'Trabalhador' ? 'selected' : ''}>Trabalhador</option><option ${doc.type === 'Veículo' ? 'selected' : ''}>Veículo</option><option ${doc.type === 'Bem / Material' ? 'selected' : ''}>Bem / Material</option></select></td>
  <td><input data-field="name" value="${doc.name || ''}" placeholder="Nome do documento"></td>
  <td><select data-field="required"><option ${doc.required !== 'Não' ? 'selected' : ''}>Sim</option><option ${doc.required === 'Não' ? 'selected' : ''}>Não</option></select></td>
  <td><select data-field="periodicity"><option>Sem periodicidade</option><option ${doc.periodicity === 'Mensal' ? 'selected' : ''}>Mensal</option><option ${doc.periodicity === 'Semestral' ? 'selected' : ''}>Semestral</option><option ${doc.periodicity === 'Anual' ? 'selected' : ''}>Anual</option><option ${doc.periodicity === 'Conforme vencimento' ? 'selected' : ''}>Conforme vencimento</option></select></td>
  <td><select data-field="validation"><option ${doc.validation === 'Manual' ? 'selected' : ''}>Manual</option><option ${doc.validation === 'IA' ? 'selected' : ''}>IA</option><option ${doc.validation === 'Automática' ? 'selected' : ''}>Automática</option></select></td>
  <td><button type="button" class="remove-row">×</button></td>`;
  $('.remove-row', row).onclick = () => row.remove();
  $('#documentsBody').appendChild(row);
}

function renderReview() {
  const data = collectWizardData();
  const cards = wizardSections.slice(0, -1).map((section, index) => {
    const inputs = $$('input, select, textarea', section).filter(el => el.name);
    const completed = inputs.filter(el => el.type === 'checkbox' ? el.checked : String(el.value).trim()).length;
    const status = completed ? 'Preenchido' : 'Pendente';
    return `<article class="review-card"><strong>${index + 1}. ${section.dataset.title}</strong><span>${status}</span><p class="muted">${completed} campo(s) informado(s)</p></article>`;
  });
  cards.push(`<article class="review-card"><strong>Documentos cadastrados</strong><span>${data.documents.length} item(ns)</span><p class="muted">Revise antes do envio.</p></article>`);
  $('#reviewSummary').innerHTML = cards.join('');
}

function downloadJSON() {
  saveWizardData(false);
  const project = getActiveProject();
  const payload = { project, answers: state.forms[project.id], exportedAt: new Date().toISOString() };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob); const a = document.createElement('a');
  a.href = url; a.download = `parametrizacao-${project.client.toLowerCase().replace(/\s+/g, '-')}.json`; a.click(); URL.revokeObjectURL(url);
}

function setupWizard() {
  $('#addDocumentButton').onclick = () => addDocumentRow();
  $('#saveButton').onclick = () => saveWizardData(true);
  $('#previousButton').onclick = () => { saveWizardData(false); if (currentWizardStep > 0) currentWizardStep--; updateWizard(); };
  $('#nextButton').onclick = () => {
    saveWizardData(false);
    if (currentWizardStep < wizardSections.length - 1) { currentWizardStep++; updateWizard(); }
    else { const project = getActiveProject(); project.progress = 100; project.status = 'Concluído'; persist(); renderDashboard(); renderProjects(); showToast('Parametrização finalizada.'); switchView('dashboard'); }
  };
  $('#downloadButton').onclick = downloadJSON;
  $('#submitButton').onclick = () => { saveWizardData(false); showToast('Configuração enviada para revisão.'); };
}

function init() {
  setupLogin(); setupNavigation(); setupProjectDialog(); setupWizard();
  $('#projectSearch').addEventListener('input', renderProjects);
  $('#projectStatusFilter').addEventListener('change', renderProjects);
  renderDashboard(); renderProjects(); loadWizardData();
}

document.addEventListener('DOMContentLoaded', init);
